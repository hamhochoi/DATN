from language.language import Languague


class Action(Languague):
    ###################################
    # ACTION PARSER

    def __init__(self):
        Languague.__init__()


    def action_parser(self):        
        pass
